import torch
from torch import nn, autograd
from torch.utils.data import DataLoader, Dataset
import torch.nn.functional as F
from models.Nets import CNNMnist
import copy

class DatasetSplit(Dataset):
    def __init__(self, dataset, idxs):
        self.dataset = dataset
        self.idxs = list(idxs)

    def __len__(self):
        return len(self.idxs)

    def __getitem__(self, item):
        image, label = self.dataset[self.idxs[item]]
        return image, label

class Client():
    
    def __init__(self, args, dataset=None, idxs=None, w = None ,pub=None,priv=None):
        '''
        w是模型参数
        idxs是dataset数据集里哪些项属于此client
        '''
        self.args = args
        self.loss_func = nn.CrossEntropyLoss()
        self.ldr_train = DataLoader(DatasetSplit(dataset, idxs), batch_size=self.args.local_bs, shuffle=True)
        self.model = CNNMnist(args=args).to(args.device)
        self.model.load_state_dict(w)
        self.pub=pub #公钥
        self.priv=priv #私钥
        
    def train(self):
        w_old = copy.deepcopy(self.model.state_dict())
        net = copy.deepcopy(self.model)

        net.train()
        
        #train and update
        optimizer = torch.optim.SGD(net.parameters(), lr=self.args.lr, momentum=self.args.momentum)
        for iter in range(self.args.local_ep):#每次client训练local_ep轮，并对本地模型进行更新
            batch_loss = []
            for batch_idx, (images, labels) in enumerate(self.ldr_train):
                images, labels = images.to(self.args.device), labels.to(self.args.device)
                net.zero_grad()
                log_probs = net(images)
                loss = self.loss_func(log_probs, labels)
                loss.backward()
                optimizer.step()
                batch_loss.append(loss.item())
        
        w_new = net.state_dict()#本地训练更新模型后的每层参数

        update_w = {}
        if self.args.mode == 'plain' or self.args.mode == 'DP':
            for k in w_new.keys():
                update_w[k] = w_new[k] - w_old[k]#计算每一层参数的delta
                
        elif self.args.mode == 'Paillier':
            for k in w_new.keys():
                update_w[k] = w_new[k] - w_old[k]#计算每一层参数的delta
                update_w[k] = update_w[k].view(update_w[k].numel()).cpu().numpy().tolist()#化为一维list
                update_w[k] = [self.pub.encrypt(x) for x in update_w[k]]#加密

        #print("client loss： ",sum(batch_loss) / len(batch_loss))
        return update_w, sum(batch_loss) / len(batch_loss) #后者是每个batch的平均损失

    def update(self, w_glob):
        if self.args.mode == 'plain' or self.args.mode == 'DP':
            self.model.load_state_dict(w_glob)
        
        elif self.args.mode =='Paillier':
            update_w_avg={}
            for k in w_glob.keys():#对每一层进行解码并更新模型
                #print("w_glob: ",w_glob[k])
                update_w_avg[k]=[self.priv.decrypt(x) for x in w_glob[k]]
                self.model.state_dict()[k] += torch.Tensor(update_w_avg[k]).view(self.model.state_dict()[k].shape).to(self.args.device)
