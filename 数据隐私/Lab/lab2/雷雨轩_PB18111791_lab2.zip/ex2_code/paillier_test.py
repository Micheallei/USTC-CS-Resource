"""
"""
import random, sys 
import time
from gmpy2 import mpz, powmod, invert, is_prime, random_state, mpz_urandomb, rint_round, log2, gcd 

rand=random_state(random.randrange(sys.maxsize))

class PrivateKey(object):
    def __init__(self, p, q, n):
        if p==q:
            self.l = p * (p-1) #欧拉函数lambda
        else:
            self.l = (p-1) * (q-1)
        try:
            self.m = invert(self.l, n) #计算mu
        except ZeroDivisionError as e:
            print(e)
            exit()

class PublicKey(object):
    def __init__(self, n):
        self.n = n
        self.n_sq = n * n
        self.g = n + 1
        self.bits=mpz(rint_round(log2(self.n))) #这里即求n的位数

def generate_prime(bits):    
    """Will generate an integer of b bits that is prime using the gmpy2 library 生成对应bit的素数 """    
    while True:
        possible =  mpz(2)**(bits-1) + mpz_urandomb(rand, bits-1 )
        if is_prime(possible):
            return possible

def generate_keypair(bits):
    """ Will generate a pair of paillier keys bits>5"""
    p = generate_prime(bits // 2)
    #print(p)
    q = generate_prime(bits // 2)
    #print(q)
    n = p * q
    return PrivateKey(p, q, n), PublicKey(n)

def enc(pub, plain):#(public key, plaintext) #to do
    while True:
        r = mpz_urandomb(rand, pub.bits)
        if r<pub.n and gcd(r,pub.n)==1:
            break
    cipher = powmod( powmod(pub.g,plain,pub.n**2) * powmod(r,pub.n ,pub.n**2),1,pub.n**2) 
    return cipher

def dec(priv, pub, cipher): #(private key, public key, cipher) #to do
    plain = powmod( ( (powmod(cipher,priv.l,pub.n**2)-1) // pub.n ) * priv.m , 1 ,pub.n)
    return plain

def enc_add(pub, m1, m2): #to do
    """Add one encrypted integer to another"""
    add_cipher = powmod(m1*m2,1,pub.n**2)  #对输入的两个密文求和的算法
    return add_cipher

def enc_add_const(pub, m, c): #to do
    """Add constant n to an encrypted integer"""
    add_const_cipher = powmod( powmod(m,1,pub.n**2) * powmod(pub.g,c,pub.n**2),1,pub.n**2)
    return add_const_cipher

def enc_mul_const(pub, m, c): #to do
    """Multiplies an encrypted integer by a constant"""
    mul_const_cipher = powmod(m,c,pub.n**2)
    return mul_const_cipher

if __name__ == '__main__':
    priv, pub = generate_keypair(1024)

    result = dec(priv=priv,pub=pub,cipher=enc_add(pub,enc(pub,1000),enc(pub,5000)))
    print(result)
    result = dec(priv=priv,pub=pub,cipher=enc_add_const(pub,enc(pub,10),5000))
    print(result)
    result = dec(priv=priv,pub=pub,cipher=enc_mul_const(pub,enc(pub,10),5000))
    print(result)
    #test1
    a=generate_prime(900)
    b=generate_prime(900)

    begin = time.time()#开始计时
    result = dec(priv=priv,pub=pub,cipher=enc_add(pub,enc(pub,a),enc(pub,b)))
    end = time.time()
    print("enc_add 用时：",end-begin," s")
    print(result==a+b)

    #test2
    a=generate_prime(999)
    b=generate_prime(999)
    result = dec(priv=priv,pub=pub,cipher=enc_add_const(pub,enc(pub,a),b))
    print(result==a+b)

    #test3
    a=generate_prime(500)
    b=generate_prime(500)
    result = dec(priv=priv,pub=pub,cipher=enc_mul_const(pub,enc(pub,a),b))
    print(result==a*b)



