import numpy as np
# from numpy.lib.function_base import gradient
import torch
from torchvision import datasets, transforms, utils
from models.Nets import CNNMnist
from options import args_parser
from client import *
from server import *
import copy
from phe import paillier
import time

def load_dataset():#加载数据集
    trans_mnist = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
    dataset_train = datasets.MNIST('./data/mnist/', train=True, download=True, transform=trans_mnist)
    dataset_test = datasets.MNIST('./data/mnist/', train=False, download=True, transform=trans_mnist)
    return dataset_train, dataset_test

def create_client_server():#创建client和server
    num_items = int(len(dataset_train) / args.num_users)#对应每个client会分到多少个数据项
    clients, all_idxs = [], [i for i in range(len(dataset_train))]#all_idxs是每个数据一个编号， clients存放创建的所有client
    net_glob = CNNMnist(args=args).to(args.device)

    public_key, private_key = paillier.generate_paillier_keypair(n_length=256)#生成密钥
    #平分训练数据，i.i.d.
    #初始化同一个参数的模型
    for i in range(args.num_users):
        new_idxs = set(np.random.choice(all_idxs, num_items, replace=False))#为一个client随机抽取数据集
        all_idxs = list(set(all_idxs) - new_idxs)
        new_client = Client(args=args, dataset=dataset_train, idxs=new_idxs, w=copy.deepcopy(net_glob.state_dict()),pub=public_key,priv=private_key)
        clients.append(new_client)

    server = Server(args=args, w=copy.deepcopy(net_glob.state_dict()),pub=public_key)

    return clients, server

if __name__ == '__main__':

    args = args_parser()
    args.device = torch.device('cuda:{}'.format(args.gpu) if torch.cuda.is_available() and args.gpu != -1 else 'cpu')
    print(args.device)

    print("load dataset...")
    dataset_train, dataset_test = load_dataset()

    print("clients and server initialization...")
    clients, server = create_client_server()

    # training
    print("start training...")
    for iter in range(args.epochs):#总的训练轮数

        begin = time.time()#开始计时

        server.clients_update_w, server.clients_loss = [], []
        for idx in range(args.num_users):#对每个client
            update_w, loss = clients[idx].train()#训练
            server.clients_update_w.append(update_w)
            server.clients_loss.append(loss)

        # calculate global weights
        print("calculate global")
        w_glob, loss_glob = server.FedAvg()#对每个client训练出来的参数做整合，得到最终更新后的参数以及client平均损失

        # update local weights
        print("update local weights")
        for idx in range(args.num_users):
            clients[idx].update(w_glob)

        end = time.time()
        print("单轮训练时间： ",end-begin," s")
        
        # print loss
        if args.mode =='Paillier':#相当于每次又把更新后的模型参数传递给server,实际是不允许的，这里只是为了检验正确性
            server.model.load_state_dict(clients[0].model.state_dict())

        acc_train, loss_train = server.test(dataset_train)
        acc_test, loss_test = server.test(dataset_test)
        print('Round {:3d}, Training average loss {:.3f}'.format(iter, loss_glob))
        print("Round {:3d}, Testing accuracy: {:.2f}".format(iter, acc_test))

    # testing

    acc_train, loss_train = server.test(dataset_train)
    acc_test, loss_test = server.test(dataset_test)
    print("Training accuracy: {:.2f}".format(acc_train))
    print("Testing accuracy: {:.2f}".format(acc_test))
