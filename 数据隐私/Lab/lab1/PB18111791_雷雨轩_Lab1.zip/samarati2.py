import pandas as pd
import random
from treelib import Tree, Node
import copy
import sys
import numpy as np
import time

def tree_build(filename):#读取如adult_gender.txt文件并生成对应的泛化树
    tree = Tree()
    tree.create_node(tag='*', identifier='*')
    #tree.show()
    with open(filename,'r') as f:
        for line in f.readlines():
            child1 , parent1=line.split(",")
            parent1=parent1.strip() #去掉换行符
            tree.create_node(tag=child1,identifier=child1,parent=parent1)
    tree.show()
    return tree

all_attr=['age', 'work_class', 'final_weight', 'education',
        'education_num', 'marital_status', 'occupation', 'relationship',
        'race', 'sex', 'capital_gain', 'capital_loss', 'hours_per_week',
        'native_country', 'class']
drop_attr=['work_class', 'final_weight', 'education',
        'education_num', 'relationship', 'capital_gain', 'capital_loss', 'hours_per_week',
        'native_country', 'class']
QI_attr=['sex', 'race', 'marital_status','age'] #实验里要用到的QI标识属性

K=10 #k匿名参数
maxSup=20#最大删除数

tree_set={}#保存所有属性的泛化树
tree_set['sex']=tree_build("./data/adult_gender.txt")
tree_set['marital_status']=tree_build("./data/adult_marital_status.txt")
tree_set['race']=tree_build("./data/adult_race.txt")

#为了应用pandas的apply函数，把泛化层次组织成多层字典的形式，hier -> x_hierarchy -> 具体要泛化到每一层时，需要把底层那个属性映射到上层哪个属性
age_hierarchy={4:['*'],
                3:['[0,19]', '[20,39]', '[40,59]', '[60,79]', '[80,99]'],
                2:['[10,19]', '[20,29]', '[30,39]', '[40,49]','[50,59]', '[60,69]', '[70,79]', '[80,89]', '[90,99]'],
                1:['[10,14]', '[15,19]', '[20,24]', '[25,29]', '[30,34]','[35,39]', '[40,44]', '[45,49]', '[50,54]', '[55,59]',
                    '[60,64]', '[65,69]', '[70,74]', '[75,79]','[80,84]', '[85,89]', '[90,94]', '[95,99]']}
sex_hierarchy={1:{'Male':'*','Female':'*'}}
race_hierarchy={1:{'Other':'*','Amer-Indian-Eskimo':'*','Black':'*','White':'*','Asian-Pac-Islander':'*'}}
marital_status_hierarchy={1:{'Never-married':'NM',
                        'Married-civ-spouse':'Married', 'Married-AF-spouse':'Married',
                        'Divorced':'leave','Separated':'leave',
                        'Widowed':'alone','Married-spouse-absent':'alone'},
                        2:{'Never-married':'*',
                        'Married-civ-spouse':'*', 'Married-AF-spouse':'*',
                        'Divorced':'*','Separated':'*',
                        'Widowed':'*','Married-spouse-absent':'*'}}
hier={'age':age_hierarchy,'sex':sex_hierarchy,'race':race_hierarchy,'marital_status':marital_status_hierarchy}


def map_func(age,value):
    #由观察发现age属性的特点，即可以根据泛化所在层数以及age的值来快速定位要泛化到的范围，
    #如value=1时，是以5为单位来泛化，所以age=14对应应该泛化到  14//5 -2 =0即hier['age'][1][0]对应的那个值'10-14'
    if value==1:
        return hier['age'][1][age//5 -2]
    elif value==2:
        return hier['age'][2][age//10 -1]
    else:
        return hier['age'][3][age//20]


def cal_LM(frame,vec,sup):#计算LM
    LM_every_attr={}#保存每一个属性的LM值
    length=frame.shape[0]#匿名数据集记录数
    for i,value in enumerate(vec):
        attr=QI_attr[i]
        LM_every_attr[attr]=0#初始化
        if value==0: #即此属性没有泛化
            continue
        if attr=='age':
            A=90-17+1
            if value==1:
                LM_every_attr[attr]=4/(A-1)
            elif value==2:
                LM_every_attr[attr]=9/(A-1)
            elif value==3:
                LM_every_attr[attr]=19/(A-1)
            elif value==4:
                LM_every_attr[attr]=1

            LM_every_attr[attr]=length*LM_every_attr[attr]/(length+sup) + sup/(length+sup)  #即被删去的记录可以视为都泛化到了*
        else:
            A=len(tree_set[attr].leaves())#泛化树的叶结点总数
            for i in range(0,length+sup):
                #print("i: ",i)
                #print("length: ",length)
                try:
                    cur_level = frame.loc[i,attr]
                    M = len(tree_set[attr].subtree(cur_level).leaves())
                    LM_every_attr[attr] += (M-1)/(A-1)
                except:
                    #print("i:",i)
                    continue
            LM_every_attr[attr] = (LM_every_attr[attr]+sup)/(length+sup)
    LM=0
    for key,value in LM_every_attr.items():
        LM+=value
    return LM

def Samarati_addi(lattice,datapd,height):#附加题的
    result=datapd
    #sup=0 #表明算法成功时删去了多少条记录
    #记录当前最好的LM值（越小越好）时对应的情况
    cur_LM=1000000 
    cur_sup=0#表明算法成功时删去了多少条记录
    cur_vec=[0,0,0,0]

    cur_try=0#从第0层开始，依次往上遍历所有可能的结果
    while cur_try<height:
        vectors = [vec for vec in lattice if sum(vec)==cur_try ] #获得满足条件的vector
        while len(vectors)!=0:
            vec = vectors.pop()
            temp_df = datapd.copy(deep=True)
            #以下即判断对于给定的vec，泛化是否能满足k和maxsup的要求
            for i,value in enumerate(vec): #对每一个QI属性分别泛化
                if value==0: 
                    continue #不需要泛化的属性
                attr=QI_attr[i]
                if attr!='age':#不是age的属性取值都是字符串类型，与数值范围型age的处理区分开来
                    temp_df[attr] = temp_df[attr].apply(lambda x: hier[attr][value][x])
                else:
                    cur_level=hier[attr][value]
                    if value==4:#最高层级
                        temp_df.loc[:,attr]='*'
                    else:#是age且不是泛化到最高层级时，调用map_func函数来进行泛化
                        temp_df[attr] = temp_df[attr].apply(lambda x:map_func(x,value))
            #将泛化后的数据集按Qi-cluster分组，并把记录数<K的除去        
            filter_df = temp_df.groupby(QI_attr).filter(lambda x: len(x) >= K)
            if temp_df.shape[0]-filter_df.shape[0] <= maxSup:
                #此时删去的记录数小于等于maxSup,表明这是一个成功的方案
                lm=cal_LM(filter_df,vec,temp_df.shape[0]-filter_df.shape[0])
                if lm >= cur_LM:#说明当前lm值不如之前找到的方案
                    continue
                cur_vec = vec
                result=filter_df.copy(deep=True)
                cur_sup=temp_df.shape[0]-filter_df.shape[0]
                cur_LM=lm
        cur_try+=1
    return result,cur_LM,cur_sup,cur_vec
                    

if __name__ == '__main__':
    #读数据集，并去掉不需要的列
    datapd=pd.read_table('./data/adult.data',sep=', ',header=None,engine='python')
    datapd.columns =all_attr
    datapd=datapd.replace("?",np.nan)
    datapd=datapd.dropna()
    all_attr.insert(-1, all_attr.pop(all_attr.index('occupation')))
    datapd = datapd.loc[:, all_attr]
    datapd=datapd.drop(drop_attr, axis=1)
    datapd = datapd.reset_index(drop = True)
    #构建lattice，计算lattice的最高高度
    lattice = [[a,b,c,d] for a in range(2) for b in range(2) for c in range(3) for d in range(5)] #age,sex,race, marital _status
    height = 4+1+1+2


    #__console = sys.stdout
    #file = open('./test.txt','w')
    #sys.stdout = file
    
    #计时并运行Samarati算法
    starttime = time.time()
    anonymity_set,LM,sup,vec = Samarati_addi(lattice,datapd,height)#选做
    endtime = time.time()

    #file.close()
    #sys.stdout = __console
    print('总共的时间为:', round(endtime - starttime, 2),'secs')
    print("删除的记录数：",sup)
    print("最终的vec: ",vec)
    print("LM: ",LM)
    #输出数据集
    anonymity_set.to_csv('samarati2_dataset.csv', index=False)