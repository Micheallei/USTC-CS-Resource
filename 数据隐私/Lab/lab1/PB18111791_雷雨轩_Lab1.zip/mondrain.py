import pandas as pd
import random
from treelib import Tree, Node
import copy
import sys
import time
import numpy as np

def tree_build(filename):
    tree = Tree()
    tree.create_node(tag='*', identifier='*')
    #tree.show()
    with open(filename,'r') as f:
        for line in f.readlines():
            child1 , parent1=line.split(",")
            parent1=parent1.strip() #去掉换行符
            tree.create_node(tag=child1,identifier=child1,parent=parent1)
    tree.show()
    return tree


all_attr=['age', 'work_class', 'final_weight', 'education',
        'education_num', 'marital_status', 'occupation', 'relationship',
        'race', 'sex', 'capital_gain', 'capital_loss', 'hours_per_week',
        'native_country', 'class']
drop_attr=['work_class', 'final_weight', 'education', 'relationship','sex','marital_status',
        'race', 'capital_gain', 'capital_loss', 'hours_per_week','native_country', 'class']
QI_attr=[('age',0),('education_num',0)] #实验里要用到的QI标识属性, 0/1代表是数值型/类别型
#QI_attr=[('age',0),('education_num',0),('sex',1),('marital_status',1)]
K=10 #k匿名参数
anonymity_set = []

tree_set={}#保存所有属性的泛化树
tree_set['sex']=tree_build("./data/adult_gender.txt")
tree_set['marital_status']=tree_build("./data/adult_marital_status.txt")


pd.set_option('display.max_rows',None)


class attr_frame():
    def __init__(self,pdframe,attr_level):
        self.data_pd=pdframe   #当前记录集数据的dataframe
        self.attr_level=attr_level  #当前记录集每个属性的划分层次，为字典形式
        #如原始数据集，则为{'age':[17,90], 'education_num':[1,16], 'sex':'*'}

count=0#记录共划分成了多少个数据集
def Mondrain(frame):
    global count
    order = [x for x in range(0,len(QI_attr))]
    random.shuffle(order) #即随机选取一个属性来做划分

    #print("order:",order)

    flag=0#判断当前记录集能否划分
    frame_set=[] #存放由frame拆分后的集合
    for i in order:#判断当前属性是否可以用来划分
        dim,dim_type = QI_attr[i]
        if dim_type == 0:#数值型属性
            splitVal = frame.data_pd[dim].median()#寻找中位数
            #尝试划分并对划分结果是否满足k匿名做判断
            lhs = frame.data_pd.loc[frame.data_pd[dim] <= splitVal].copy(deep=True)
            rhs = frame.data_pd.loc[frame.data_pd[dim] > splitVal].copy(deep=True)
            if lhs.shape[0]>=K and rhs.shape[0]>=K:#划分后满足k匿名要求
                #划出来的左右两部分数据集做处理
                flag=1
                l_attrlevel=copy.deepcopy(frame.attr_level)
                #l_attrlevel[dim]=[l_attrlevel[dim][0],int(splitVal)]
                l_attrlevel[dim]=[lhs[dim].min(),lhs[dim].max()]
                frame_set.append(attr_frame(lhs, l_attrlevel))

                r_attrlevel=copy.deepcopy(frame.attr_level)
                #r_attrlevel[dim]=[int(splitVal)+1,l_attrlevel[dim][1]]
                r_attrlevel[dim]=[rhs[dim].min(),rhs[dim].max()]
                frame_set.append(attr_frame(rhs, r_attrlevel))
                break
        elif dim_type==1:#类别型属性
            splitVal_set=[]
            cur_level=frame.attr_level[dim] #看记录集当前所在的泛化层次
            child_levels=tree_set[dim].children(cur_level)#下一层级泛化
            for subnode in child_levels:#根据该层的名字，找到该名字对应的子树的叶结点的名字集合
                subname=subnode.identifier
                leaves = tree_set[dim].subtree(subname).leaves()
                splitVal_set.append([leave.identifier for leave in leaves])
            #划分数据集
            data_set=[frame.data_pd.loc[frame.data_pd[dim].isin(splitVal)].copy(deep=True) for splitVal in splitVal_set]
            #print(data_set)
            if len(child_levels)>0 and all(i.shape[0]>=K for i in data_set):#此时表示可以划分,那么加入调用递归函数的集合frame_set
                flag=1
                for i in range(len(child_levels)):
                    cattrlevel=copy.deepcopy(frame.attr_level)
                    cattrlevel[dim]=child_levels[i].identifier
                    frame_set.append(attr_frame(data_set[i],cattrlevel))
                break
    if flag==0:#不能再分了，则加入最终的满足k匿名的记录集
        #print(frame.data_pd.sort_values(by=['age','education_num']))#.to_csv("./text.csv",mode='a',index=None,header=None)
        count+=1
        for ent,_ in QI_attr:#对每个属性做泛化，其中attr_level已经记录了该Qi-cluster每个属性应该泛化到什么层次
            frame.data_pd.loc[:,ent]=frame.data_pd.loc[:,ent].apply(lambda x: frame.attr_level[ent])
        anonymity_set.append(frame)
    else:
        for partition in frame_set:#若frame能再分，那么需要对其划分出来的数据集做递归调用
            Mondrain(partition)


            
def cal_LM(frame,attr_level_init):#传入的是整个匿名数据集，以及初始的属性范围
    LM_every_attr={}
    for attr,t in QI_attr:#对每个属性计算
        LM_every_attr[attr]=0
        if t==0:#数值型
            low,high = attr_level_init[attr]
            for i in range(0,frame.shape[0]):#遍历dataframe每一行
                low_i , high_i= frame.loc[i,attr]
                LM_every_attr[attr] += (high_i-low_i)/(high-low)
            LM_every_attr[attr] = LM_every_attr[attr]/frame.shape[0]
        elif t==1:#类别型
            #root=attr_level_init[attr]
            A=len(tree_set[attr].leaves())#泛化树的叶结点总数
            for i in range(0,frame.shape[0]):
                cur_level = frame.loc[i,attr]
                M = len(tree_set[attr].subtree(cur_level).leaves())
                LM_every_attr[attr] += (M-1)/(A-1)
            LM_every_attr[attr] = LM_every_attr[attr]/frame.shape[0]
    LM=0
    for key,value in LM_every_attr.items():
        LM+=value
    return LM



if __name__ == '__main__':
    
    #数据读入
    datapd=pd.read_table('./data/adult.data',sep=', ',header=None,engine='python')
    datapd.columns =all_attr
    datapd=datapd.replace("?",np.nan)
    datapd=datapd.dropna()
    all_attr.insert(-1, all_attr.pop(all_attr.index('occupation')))
    datapd = datapd.loc[:, all_attr]
    datapd=datapd.drop(drop_attr, axis=1)
    datapd = datapd.reset_index(drop = True)

    #记录初始时每个属性的泛化情况，因为初始时可把整个数据集看为一个Qi-cluster，所以即为最顶层的泛化层级
    attr_level_init = {}
    for column,t in QI_attr:
        if t==0:
            attr_level_init[column]=[datapd[column].min(),datapd[column].max()]
        else:
            attr_level_init[column]='*'
    #print("attr_level_init: ",attr_level_init)
    frame=attr_frame(datapd,attr_level_init) #原始记录集实例


    #__console = sys.stdout
    #file = open('./test.txt','w')
    #sys.stdout = file
    starttime = time.time()

    Mondrain(frame)

    endtime = time.time()
    
    #print(anonymity_set[0].data_pd)
    final_frame = anonymity_set[0].data_pd
    for frame in anonymity_set[1:]:
        final_frame = pd.concat([final_frame,frame.data_pd])
    #print("count1: ",final_frame.groupby(['age','education_num']).count())
    
    #file.close()
    #sys.stdout = __console
    print("count:",count)
    print("LM: ",cal_LM(final_frame,attr_level_init))
    print('总共的时间为:', round(endtime - starttime, 2),'secs')
    final_frame.to_csv('mondrain_dataset.csv', index=False,header=None)