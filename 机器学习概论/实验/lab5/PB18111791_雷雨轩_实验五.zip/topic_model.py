import numpy as np
import pandas as pd
import string
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk import pos_tag
from nltk.stem import WordNetLemmatizer



class LDAGibbs:
    def __init__(self,texts,K=20):
        """
        texts：原始语料
        K：话题个数
        利用collapsed gibbs sampling方法实现LDA
        :param K: 主题个数，实验里为20
        :param V: 总共单词个数
        :param M: 文档个数，本实验为1000
        :param tokens: 词汇表tokens
        :param Rtokens: 反转词汇表，每一个词对应一个序号
        :param txt: 预处理后的语料库
        :param alpha: theta的超参数，维度(K,)
        :param theta: 文本主题矩阵，第t行表示文档t所包含的每个话题的比例。服从狄利克雷分布，维度(M,K)
        :param beta: varphi的超参数，维度(V,)
        :param varphi: 单词主题矩阵，第i行表示话题i对应的词频分布。服从狄利克雷分布，维度(K,V)
        :param z: 话题集合，维度(M,Nm),Nm表示第m个文本的单词个数, z[m][n]表示对文档m的第n个单词的话题指派
        :param sigma: 话题计数矩阵，维度(M,K), sigma[m][k]表示第m个文本第k个话题的次数
        :param delta: 单词计数矩阵，维度(K,V), delta[k][v]表示第k个话题第v个单词的个数
        """
        self.texts=texts
        self.K = K
        self.V = None
        self.M = len(texts)
        self.tokens = []
        self.Rtokens = {}
        self.txt = []

        self.params = {
            'alpha': None,
            'theta': None,
            'beta': None,
            'varphi': None,
            'z': None
        }
        self.sigma = None
        self.delta = None

    def prehandle(self,filter_freq=10):
        #对原始文本进行词性还原、去停用词、去标点、小写的处理
        #再删除出现频率较低的不常用词
        #最后得到处理后的语料库(二维列表)以及词汇表
        #即完成V,tokens,txt三项的初始化
        tokens=[]
        for i in range(len(self.texts)):
            doc=self.texts[i].lower()#变为小写
            token_word = word_tokenize(doc)#分词
            token_words = pos_tag(token_word)#打上词性标签
            words_lematizer = []
            wordnet_lematizer = WordNetLemmatizer()#词形还原器
            for word, tag in token_words:
                word = word.lower()
                if tag.startswith('NN'):
                    word_lematizer =  wordnet_lematizer.lemmatize(word, pos='n')  # n代表名词
                elif tag.startswith('VB'): 
                    word_lematizer =  wordnet_lematizer.lemmatize(word, pos='v')   # v代表动词
                elif tag.startswith('JJ'): 
                    word_lematizer =  wordnet_lematizer.lemmatize(word, pos='a')   # a代表形容词
                elif tag.startswith('R'): 
                    word_lematizer =  wordnet_lematizer.lemmatize(word, pos='r')   # r代表代词
                else: 
                    word_lematizer =  wordnet_lematizer.lemmatize(word)
                words_lematizer.append(word_lematizer)

            cleaned_words = [word for word in words_lematizer if (len(word) >= 3) and (word not in stopwords.words('english')) and (word not in string.punctuation) and word.isalpha()]

            tokens=np.concatenate((tokens,cleaned_words))
            self.txt.append(cleaned_words)
        self.tokens=np.unique(tokens)

        # 删除不常用词
        #统计词频
        wcount = {}
        for m in range(self.M):
            N = len(self.txt[m])
            for n in range(N):
                w = self.txt[m][n]
                wcount[w] = wcount.get(w,0) + 1
        #在每篇文章中删除
        for m in range(self.M):
            i = 0
            while True:
                if i >= len(self.txt[m]):
                    break
                w = self.txt[m][i]
                if wcount[w] < filter_freq:
                    #删除出现频率小于filter_freq的词
                    idx = np.where(self.tokens == w)
                    self.tokens = np.delete(self.tokens, idx)
                    self.txt[m] = np.delete(self.txt[m],i)
                else:
                    i += 1

        self.V=len(self.tokens)
        print("prehandle finished!")

    def init_params(self):
        """
        初始化参数，除了上面定义的参数，公式中统计的参数也在这儿初始化
        """
        for v in range(self.V):
            vocab = self.tokens[v]
            self.Rtokens[vocab] = v
        
        # 代表第k个主题的第v个单词个数
        self.delta = np.zeros((self.K, self.V))
        # 代表第k个主题有多少个单词(未去重)
        self.n_k = np.zeros(self.K)
        # 代表第m个文档第k个主题的单词个数
        self.sigma = np.zeros((self.M, self.K))
        # 每一个元素代表第m个文档有多少个单词
        self.n_m = np.zeros(self.M)

        alpha = np.ones(self.K)
        theta = np.ones((self.M ,self.K))# 文档主题参数先占位，最后再进行更新
        beta = np.ones(self.V)
        varphi = np.ones((self.K, self.V))# 单词主题参数也先占位，最后再进行更新
        z = []
        for m in range(self.M):
            N = len(self.txt[m])
            z.append(np.zeros(N))
        z = np.array(z)

        # 初始化中做一次统计，且对z随机初始化:对应语料库中每一篇文档的每一个单词，随机的赋予一个主题编号z
        for m in range(self.M):
            N = len(self.txt[m])
            for v in range(N):
                rand_topic = int(np.random.randint(0, self.K))
                z[m][v] = rand_topic
                self.delta[rand_topic][self.Rtokens[self.txt[m][v]]] += 1
                self.n_k[rand_topic] += 1
                self.sigma[m][rand_topic] += 1
            self.n_m[m] = N

        self.params = {
            'alpha': alpha,
            'theta': theta,
            'beta': beta,
            'varphi': varphi,
            'z': z
        }

        print("Initialization finished.")

    def collapse_gibbs_sampling(self,max_iter=100):
        for iter in range(max_iter):
            print('iter: ', iter + 1)
            for m in range(self.M):#对每一篇文章
                N = len(self.txt[m])
                for v in range(N):#对每一个单词，更新它的主题编号
                    topic = self.sample_topic(m, v)
                    self.params['z'][m][v] = topic

    def sample_topic(self, m, v):
        """
        计算z_mv对应主题的概率值，并通过概率值进行多项分布采样，返回更新后的主题
        :param m: 表示调用的时候，上层函数计算的是第m个文档
        :param v: 第v个单词
        """
        # 首先是排除当前的单词z[m][v],即把旧指派对应的参数去除
        old_topic = int(self.params['z'][m][v])
        self.delta[old_topic][self.Rtokens[self.txt[m][v]]] -= 1
        self.n_k[old_topic] -= 1
        self.sigma[m][old_topic] -= 1
        self.n_m[m] -= 1

        # 依次计算该单词的p(z_mv=k | *)
        p = np.zeros(self.K)
        for k in range(self.K):
            p[k] = (self.sigma[m][k] + self.params['alpha'][k]) / (self.n_m[m] + np.sum(self.params['alpha'])) * \
                   (self.delta[k][self.Rtokens[self.txt[m][v]]] + self.params['beta'][self.Rtokens[self.txt[m][v]]]) / (self.n_k[k] + np.sum(self.params['beta']))

        # 对概率进行归一化处理
        p = p / np.sum(p)

        # 抽样新的主题
        new_topic = np.argmax(np.random.multinomial(1, p))

        # 更新统计值
        self.delta[new_topic][self.Rtokens[self.txt[m][v]]] += 1
        self.n_k[new_topic] += 1
        self.sigma[m][new_topic] += 1
        self.n_m[m] += 1

        return new_topic

    def update_params(self):
        """
        计算得到两个参数矩阵：theta,varphi
        """
        # 依据统计值，更新单词主题矩阵和文档主题矩阵
        #varphi: 单词主题矩阵，第i行表示话题i对应的词频分布。服从狄利克雷分布，维度(K,V)
        for k in range(self.K):
            for v in range(self.V):
                self.params['varphi'][k][v] = (self.delta[k][v] + self.params['beta'][v]) / (self.n_k[k] + np.sum(self.params['beta']))

        #theta: 文本主题矩阵，第t行表示文档t所包含的每个话题的比例。服从狄利克雷分布，维度(M,K)
        for m in range(self.M):
            for k in range(self.K):
                self.params['theta'][m][k] = (self.sigma[m][k] + self.params['alpha'][k]) / (self.n_m[m] + np.sum(self.params['alpha']))

    def count_top_words(self, top_k = 10):
        #计算得到每个话题的top10的单词（按概率从大到小）
        topic_word_bag = []
        for k in range(self.K):
            word_bag_idx = np.argsort(-self.params['varphi'][k])[0:top_k]#取负号以获得降序排列序号
            word_bag = self.tokens[word_bag_idx]
            topic_word_bag.append(list(word_bag))
        return np.array(topic_word_bag)

if __name__ == '__main__':
    texts=np.load("./text.npy")
    LDA=LDAGibbs(texts)
    LDA.prehandle()
    LDA.init_params()

    print("语料集统计数据：")
    print("M =",LDA.M,"K =",LDA.K,"V =",LDA.V)
    print("词汇表前十个单词:")
    for i in range(10):
        print(LDA.tokens[i])
    print("begin iteration！")
    LDA.collapse_gibbs_sampling()
    print("iteration finished!")
    LDA.update_params()
    top_words_bag=LDA.count_top_words()
    for i in range(LDA.K):
        print(top_words_bag[i])
    np.savetxt("result.txt",top_words_bag,fmt='%s',delimiter=',')