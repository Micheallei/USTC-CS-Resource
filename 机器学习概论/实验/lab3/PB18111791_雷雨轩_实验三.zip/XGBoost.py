import numpy as np
from graphviz import Digraph


class LogisticLoss():#y为真实标记，p为已求得的各棵树对应权重之和
    def grad(self, y, p):#一阶导数值
        y_pred = 1 - 1 / (1 + np.exp(p))
        return y_pred - y

    def hess(self, y, p):#二阶导数值
        temp = np.exp(-p)
        return temp / np.square(1 + temp)


class Node:
    def __init__(self, feature=None, threshold=None, left=None, right=None, value=None):
        self.left = left#左子树
        self.right = right#右子树
        self.feature = feature#用的第几个特征
        self.threshold = threshold#用的该特征的哪个取值
        self.value = value#叶结点才有的权值



class XGBoostTree:
    def __init__(self,split_size=2,min_gain=1e-5,max_depth=3,loss_func=None,lamb_da=1.1,gamma=0.2,eta=0.61):
        '''
        root:树根
        split_size:结点分裂的样本阈值，即该结点样本数大于等于该值时才考虑分裂
        min_gain:增益的阈值
        max_depth:树的最大深度
        loss_func:损失函数
        lamb_da
        gamma
        eta:学习率
        '''
        self.split_size = split_size
        self.min_gain = min_gain
        self.max_depth = max_depth
        self.loss_func = loss_func
        self.lamb_da = lamb_da
        self.gamma = gamma
        self.eta=eta
        self.root = None

    def fit(self, X, y, p):
        Xyp = np.c_[X, y, p]#按行连接向量构成矩阵
        self.root = self.tree_generate(Xyp)

    def tree_generate(self, Xyp, cur_depth=0):
        #存放当前结点选择的划分特征及其取值的信息
        max_gain = float('-inf')#负无穷
        feature = None
        threshold = None
        split_num = None
        num = None

        LXyp = None#左子树结点集合
        RXyp = None#右子树结点集合

        size = np.shape(Xyp)[0]#样本个数
        feature_num = np.shape(Xyp)[1] - 2#特征数
        G = self.loss_func.grad(Xyp[:, -2], Xyp[:, -1])#计算一阶导
        H = self.loss_func.hess(Xyp[:, -2], Xyp[:, -1])#计算二阶导
        if size >= self.split_size and cur_depth <= self.max_depth:
            for f in range(feature_num):#对每个特征分别计算最大的增益Gain
                g_l = 0
                h_l = 0
                #print(Xyp.T[f,None])
                #print(Xyp.T[f])
                sorted_num=np.lexsort(Xyp.T[f,None])#按特征f值大小排序后的序号
                Xyp_sorted = Xyp[sorted_num]
                #print(sorted_num)
                #print(Xyp_sorted)
                G_sorted = G[sorted_num]
                H_sorted = H[sorted_num]

                unique_values = np.unique(Xyp[:, f])#从小到大的取值
                for fv in unique_values[1:]:#最小的那个特征取值不用算，因为这样分没有意义
                    split_i = np.searchsorted(Xyp_sorted[:, f], fv)#该取值在排序后的数据里的序号
                    g_l = np.sum(G_sorted[:split_i])
                    g_r = np.sum(G_sorted[split_i:])
                    h_l = np.sum(H_sorted[:split_i])
                    h_r = np.sum(H_sorted[split_i:])
                    gain = 0.5*(np.square(g_l)/(h_l+self.lamb_da) + np.square(g_r)/(h_r+self.lamb_da)
                                - np.square(g_l+g_r)/(h_l+h_r+self.lamb_da)) - self.gamma
                    if gain > max_gain and gain > self.min_gain:
                        #当前计算出的增益比已得到的max_gain大，且大于增益阈值min_gain,作一个暂时的存储
                        max_gain = gain
                        feature = f
                        threshold = fv
                        split_num = split_i
                        num=sorted_num
            if max_gain > self.min_gain:
                LXyp = Xyp[num[:split_num]]
                RXyp = Xyp[num[split_num:]]
                left = self.tree_generate(LXyp, cur_depth + 1)
                right = self.tree_generate(RXyp, cur_depth + 1)
                return Node(feature, threshold, left, right)
        #若某个结点未分裂，意味着其会成为叶结点，则生成叶结点，并计算叶结点权重
        leaf_value = -np.sum(G) * self.eta / (np.sum(H) + self.lamb_da)
        leaf = Node(value=leaf_value)
        return leaf

    def x_weight(self, x, node):#向下走到叶结点，然后返回对应权重
        if node.value is not None:
            return node.value
        feature_value = x[node.feature]
        if feature_value < node.threshold:
            return self.x_weight(x, node.left)
        else:
            return self.x_weight(x, node.right)

    def predict(self, X):#计算这棵树对每个样本的预测值，也即对应叶结点的权值
        y_pred = []
        for x in X:
            y_pred.append(self.x_weight(x, self.root))
        p=np.array(y_pred)
        return p




class XGBoost(object):
    def __init__(self, total_treenum=3, split_size=2, min_gain=1e-5, max_depth=3):
        '''
        total_treenum:训练树的棵数
        split_size:结点分裂的样本阈值，即该结点样本数大于等于该值时才考虑分裂
        min_gain:增益的阈值
        max_depth:树的最大深度
        loss_func:损失函数
        '''
        self.total_treenum = total_treenum
        self.split_size = split_size
        self.min_gain = min_gain
        self.max_depth = max_depth
        self.loss_func = LogisticLoss()
        self.trees = []
        for _ in range(total_treenum):#把待训练的所有树初始化
            tree = XGBoostTree(
                split_size=self.split_size,
                min_gain=self.min_gain,
                max_depth=self.max_depth,
                loss_func=self.loss_func)
            self.trees.append(tree)

    def fit(self, X, y):#参数为训练集数据
        p = np.zeros(np.shape(y))#初始预测值为0，对应f_0(x)
        for tree in self.trees:
            tree.fit(X, y, p)
            p += tree.predict(X)#迭代增，下一棵树的生成是拟合当前残差

    def predict(self, X):
        y_pred = np.zeros(X.shape[0])
        for tree in self.trees:
            y_pred += tree.predict(X)#各棵树预测值相加
        return np.int64(y_pred > 0)#分类问题，用对率函数把预测值映射到0/1标签

    def tree_graph(self):
        for i,tree in enumerate(self.trees):
            graph = Digraph()
            if tree.root.value is None:#根结点，输出划分特征
                graph.node('root', "x{} < {:.7g}".format(tree.root.feature, tree.root.threshold),color='blue',shape='circle')
                self.rec_node_graph(graph, tree.root, 'root')
            else:
                graph.node('root', "leaf = {:.7g}".format(tree.root.value), color='red',shape='box')
            graph.render('Tree%s' % (i + 1), format='svg', cleanup=True,view=False)


    def rec_node_graph(self, graph, node, name):#从根结点递归向下作图
        left = node.left
        right = node.right
        if left.value is None:
            graph.node(name+'l', "x{} < {:.7g}".format(left.feature, left.threshold),color='blue',shape='circle')
            graph.edge(name, name+'l', color='green', label='t')
            self.rec_node_graph(graph, left, name+'l')
        else:
            graph.node(name+'l', "leaf = {:.7g}".format(left.value), color='red',shape='box')
            graph.edge(name, name+'l', color='green', label='t')
        if right.value is None:
            graph.node(name+'r', "x{} < {:.7g}".format(right.feature, right.threshold),color='blue',shape='circle')
            graph.edge(name, name+'r', color='orange', label='f')
            self.rec_node_graph(graph, right, name+'r')
        else:
            graph.node(name+'r', "leaf = {:.7g}".format(right.value), color='red',shape='box')
            graph.edge(name, name+'r', color='orange', label='f')



def main():
    '''
    x_train_1 = np.array([[1,-5],[2,5],[3,-2],[1,2],[2,0],[6,-5],[7,5],[6,-2],[7,2],[6,0],[8,-5],[9,5],[10,-2],[8,2],[9,0]])
    print(x_train_1.shape)
    y_train_1 = np.array([0,0,1,1,1,1,1,0,0,1,1,1,0,0,1])

    xgbt = XGBoost(total_treenum=2)
    xgbt.fit(x_train_1, y_train_1)  # 训练模型

    '''
    # 载入数据集
    x_train = np.load("./data/train_data.npy")  # shape: (615, 8)
    y_train = np.load("./data/train_target.npy")  # shape: (615,)
    x_test = np.load("./data/test_data.npy")  # shape: (153, 8)
    y_test = np.load("./data/test_target.npy")  # shape: (153,)

    #print(np.shape(y_train))
    #print(np.zeros(np.shape(y_train)))

    
    # 训练模型
    xgboost = XGBoost()
    xgboost.fit(x_train, y_train)  # 训练模型

    # 预测
    p_train = xgboost.predict(x_train)
    p_test = xgboost.predict(x_test)
    # 训练集和测试集精度
    print("数据集的训练集精度为：{:.2f} %".format(
        (p_train == y_train).mean() * 100))
    print("数据集的测试集精度为：{:.2f} %".format(
        (p_test == y_test).mean() * 100))

    # 画出决策子树
    xgboost.tree_graph()
    
if __name__ == "__main__":
    main()
