import numpy as np
import random
import copy
import matplotlib.pyplot as plt


def raw_graph(data):
    plt.figure(figsize=(15, 12))
    plt.title("Ori Data")
    color = ['r', 'b', 'g']
    for index, label_data in enumerate(data):
        xy = np.array(data[label_data])
        plt.scatter(xy[:, 0], xy[:, 1], s=90, label='label{}'.format(index),
                    c=color[index % len(color)])
    plt.xlabel("x")
    plt.ylabel("y")
    plt.legend()
    plt.show()

class K_means:
    def __init__(self,k,X,init_n,stop_n):
        self.init_n=init_n #选择初始化方式：1为随机生成k个点， 2为从数据集合随机抽取k个点
        self.stop_n=stop_n #选择算法终止方式： 1为簇中心向量不再发生变化，2为样本分类类别标签不再发生变化
        self.k=k
        self.X=X #存放原始数据
        self.m=X.shape[0]#样本数
        self.d=X.shape[1]#每个样本维度
        self.label=np.zeros(self.m, dtype=int)#存放迭代过程中的每个数据的标签0/1/2
        self.mu=np.zeros((self.k, self.d))#存放k个类别的均值

    def fit(self):
        self.init_mu(self.init_n)
        change=True
        iteration=0
        while(change):
            iteration+=1
            old_label=copy.deepcopy(self.label)
            for i in range(self.m):#计算样本与各均值的距离并选择最近的均值来划分标记
                self.label[i]=np.argmin(self.dist(self.X[i],self.mu,2))
            tmp_mu=self.calculate_mu()

            if(self.stop_n==1):
                if(self.mu==tmp_mu).all():#簇中心向量不再发生变化
                    change=False
            elif(old_label == self.label).all():#样本分类类别标签不再发生变化
                change=False
            self.mu=tmp_mu
        print("iteration num: ",iteration)


    def init_mu(self,n):
        if(n==1):#选择随机生成k个样本点,考虑从数据取值范围内随机生成样本点
            max_x,max_y=np.amax(self.X,axis=0)
            min_x,min_y=np.amin(self.X,axis=0)
            for i in range(self.k):
                self.mu[i][0]=random.uniform(min_x,max_x)
                self.mu[i][1]=random.uniform(min_y,max_y)
            print(self.mu)
        elif(n==2):#从数据集合中随机抽取K个样本点
            sample = random.sample(range(self.m), self.k)
            self.mu = copy.deepcopy(self.X[sample])

    def calculate_mu(self):#计算新的mu值
        tmp_mu = np.zeros((self.k, self.d))#存放新计算的mu
        for k in range(self.k):
            class_k = self.X[np.where(self.label == k)]
            if len(class_k) != 0:
                tmp_mu[k] = np.mean(class_k, axis=0)
            else:#若导致某一类没有样本
                if(self.init_n==1):#随机生成一个样本点
                    max_x,max_y=np.amax(self.X,axis=0)
                    min_x,min_y=np.amin(self.X,axis=0)
                    tmp_mu[k][0]=random.uniform(min_x,max_x)
                    tmp_mu[k][1]=random.uniform(min_y,max_y)
                    print(tmp_mu[k])
                else:#则从数据中随机取一个点作为均值向量
                    tmp_mu[k] = copy.deepcopy(self.X[random.randint(0, self.m-1)])
                    print(tmp_mu[k])
        return tmp_mu

    def dist(self, x1, x2, dim=1):
        if dim == 1:#单纯求两个点欧式距离
            return np.sqrt(np.sum(np.square(x1-x2)))
        else:#广播，同时求一个点到多个点的欧式距离
            return np.sqrt(np.sum(np.square(x1-x2), axis=1))

    def DBI(self):
        avg_C = np.zeros(self.k) #簇内样本平均距离
        for k in range(self.k):
            X_k = self.X[np.where(self.label == k)]
            if len(X_k) == 0:
                avg_C[k] = 0
            else:
                avg_C[k] = np.sum(self.dist(self.mu[k], X_k, 2))/len(X_k)
        dbi = 0
        for i in range(self.k):
            max_val = -float("inf")
            for j in range(self.k):
                if i == j:
                    continue
                max_val = max(max_val, (avg_C[i]+avg_C[j])/self.dist(self.mu[i], self.mu[j]))
            dbi += max_val
        return dbi/self.k

    def result_graph(self):
        plt.figure(figsize=(15, 12))
        plt.title("Clustering Result")
        color = ['r', 'b', 'g']
        for k in range(self.k):
            x = self.X[np.where(self.label == k)][:, 0]
            y = self.X[np.where(self.label == k)][:, 1]
            plt.scatter(x, y, s=80, label='class{}'.format(k),c=color[k % len(color)], alpha=0.4)
            plt.scatter(self.mu[k][0], self.mu[k][1], s=200, label='center{}'.format(k), marker='*', c=color[k % len(color)], linewidths=3)
        plt.xlabel("x")
        plt.ylabel("y")
        plt.legend()
        plt.show()

if __name__ == "__main__":

    # 载入数据集
    data = np.load("./data/k-means/k-means.npy", allow_pickle=True).item()
    raw_graph(data)  # 展示理想的聚类结果
    class_0 = data['class_0']
    class_1 = data['class_1']
    class_2 = data['class_2']
    raw_data = class_0+class_1+class_2
    X = np.array(raw_data)  #重新整合数据(150, 2)

    # 训练模型
    kmeans = K_means(k=3,X=X,init_n=1,stop_n=2)
    kmeans.fit()

    # 要求输出的结果
    print("各个簇的中心坐标：\n", kmeans.mu)
    dbi = kmeans.DBI()
    print("DBI = {:.4f}".format(dbi))

     #作图
    kmeans.result_graph()