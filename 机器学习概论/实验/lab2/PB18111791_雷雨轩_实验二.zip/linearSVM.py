
import numpy as np
import matplotlib.pyplot as plt

class LinearSVM:
    def __init__(self):
        self._w = None
        self._b = None
        
    def fit(self, x, y, c=1, lr=0.01, batch_size=20,M=10000):#小批量随机梯度下降法
        '''
        参数说明：
        x,y:分别对应训练集的参数X和标记y
        c:惩罚因子
        lr:学习率
        batch_size:小批量数
        M:迭代次数
        '''
        x, y = np.asarray(x, np.float32), np.asarray(y, np.float32)  #精度表示的统一
        #print(x.shape)
        self._w = np.zeros(x.shape[1])
        #print(self._w.shape)
        self._b = 0.
        batch_size=min(len(x),batch_size)#以防设定的参数比训练集规模还大
        for i in range(M):
            self._w *= 1 - lr#无论所选取的小批量样本如何，这一步梯度下降一定要做，这是根据梯度计算式得来
            batch = np.random.choice(len(x), batch_size)#随机抽取一小批量数据
            #print(batch)
            x_batch, y_batch = x[batch], y[batch]

            error = 1 - y_batch * self.predict(x_batch, True)#计算抽取的小批量数据中每个样本的error
            if np.max(error) <= 0:#若当前抽取的样本全部满足预测，则停止当前轮次的梯度下降
                continue
            # 只需用到误分类的样本做梯度下降，因为正确分类的样本的梯度为0(或者说已经在代码26行算过了)
            filt = error > 0
            delta1 = lr * c * y_batch[filt]
            delta = delta1.reshape(delta1.shape[0], 1)
            # 取各梯度平均，做一步梯度下降
            self._w += np.mean(delta * x_batch[filt], axis=0)
            self._b += np.mean(delta)


    def fit_base(self, x, y, c=10, lr=0.01,M=10000):#最基础的梯度下降法
        x, y = np.asarray(x, np.float32), np.asarray(y, np.float32)  #精度表示的统一
        self._w = np.zeros(x.shape[1])
        self._b = 0.
        for i in range(M):
            self._w *= 1 - lr
            err = 1 - y * self.predict(x, True)
            idx = np.argmax(err)
            print(idx)
            # 注意即使所有 x, y 都满足 w·x + b >= 1
            # 由于损失里面有一个 w 的模长平方
            # 所以仍然不能终止训练，只能截断当前的梯度下降
            if err[idx] <= 0:
                continue
            #self._w *= 1 - lr
            delta = lr * c * y[idx]
            self._w += delta * x[idx]
            self._b += delta

    def predict(self, x, raw=False):#计算w*x + b
        x = np.asarray(x, np.float32)#统一数据类型
        y_predict = x.dot(self._w) + self._b
        if raw:
            return y_predict
        return np.sign(y_predict).astype(np.float32)

    def draw_graph(self, X, y, title):#绘制图像
        W = self._w
        b = self._b
        print("W: ",W)
        print("b: ",b)
        w1 = W[0]
        w2 = W[1]
        #绘制超平面所在直线
        x1_low = min(X[:, 0])
        x1_high = max(X[:, 0])
        x1 = np.arange(x1_low, x1_high, 0.1)
        x2 = -w1/w2*x1 -b/w2   #w1*x1+w2*x2+b=0
        plt.plot(x1, x2, c='c', label='hyperplane')

        #绘制所有点集
        plt.scatter(X[:, 0][y == -1], X[:, 1][y == -1],
                    s=20, c="k",label='label = -1')
        plt.scatter(X[:, 0][y == 1], X[:, 1][y == 1],
                    marker='s', s=20,c="r", label='label = 1')

        plt.xlabel("X1")
        plt.ylabel("X2")
        plt.title(title)
        plt.grid()
        plt.legend()
        plt.show()



def main():
    #load data
    train_data = np.load('./data/s-svm/train_data.npy')
    train_target = np.load('./data/s-svm/train_target.npy')
    test_data = np.load('./data/s-svm/test_data.npy')
    test_target = np.load('./data/s-svm/test_target.npy')


    #train_data = np.load('./data/svm/train_data.npy')
    #train_target = np.load('./data/svm/train_target.npy')
    #test_data = np.load('./data/svm/test_data.npy')
    #test_target = np.load('./data/svm/test_target.npy')
    #print("train_target:", train_target.shape,train_target)

    svm=LinearSVM()
    svm.fit(train_data,train_target)

    predict_train=svm.predict(train_data)
    predict_test=svm.predict(test_data)

    print("训练集精度为：{:.3f} %".format(
        (predict_train == train_target).mean() * 100))
    print("测试集精度为：{:.3f} %".format(
        (predict_test == test_target).mean() * 100))


    svm.draw_graph(np.concatenate((train_data,test_data)),np.concatenate((train_target,test_target)),"result")

    
if __name__ == '__main__':
    main()