import numpy as np
import math
import matplotlib.pyplot as plt


x_train=np.load('./data/LR/train_data.npy')#应忽略第一列的值，只看后两个特征
y_train=np.load('./data/LR/train_target.npy')#真实标记
x_test=np.load('./data/LR/test_data.npy')
y_test=np.load('./data/LR/test_target.npy')#真实标记



T=5000#初始化训练轮数
beta=np.array([0,0,0])#初始化参数b,w1,w2
alpha=0.01#初始化学习率

for i in range(T):#训练，每一轮训练用所有样本损失函数的和来求导数计算，并更新beta参数向量
    delta=np.array([0,0,0])
    for k in range(70):
        delta=delta+(1/(1+math.exp(-np.sum(np.dot(x_train[k],beta))))-y_train[k])*x_train[k]
    beta=beta-alpha*delta/70

true_pre=0
for i in range(70):#评价训练集精度，若模型预测值>=0.5，判定其标签为1；否则为0
    if(1/(1+math.exp(-np.sum(np.dot(x_train[i],beta)))) >=0.5):
        if(y_train[i]==1):
            true_pre=true_pre+1
    else:
        if(y_train[i]==0):
            true_pre=true_pre+1

print("训练集精度: ",true_pre/70)
#print(beta)


t_true_pre=0
for i in range(30):#评价测试集精度，若模型预测值>=0.5，判定其标签为1；否则为0
    if(1/(1+math.exp(-np.sum(np.dot(x_test[i],beta))))>=0.5):
        if(y_test[i]==1):
            t_true_pre=t_true_pre+1
    else:
        if(y_test[i]==0):
            t_true_pre=t_true_pre+1

print("测试集精度: ",t_true_pre/30)




#画直线w1*x1+w2*x2+b=0
x1 = np.array([-4,4])
x2 = -(beta[1]/beta[2])*x1-beta[0]/beta[2]
plt.plot([x1[0],x2[0]],[x1[1],x2[1]])

#画数据点
colors = ['green', 'red']#负样例为绿色，正样例为红色
plt.scatter(x_train[:,[1]], x_train[:,[2]], c=np.array(colors)[y_train], s=15, edgecolors='none')
plt.scatter(x_test[:,[1]], x_test[:,[2]], c=np.array(colors)[y_test], s=15, edgecolors='none')
plt.show()