# -*- coding: utf-8 -*-

import module_example
if __name__ == "__main__":
    module_example.print_info() 
    
    a = module_example.TestClass(20)
    a.doSth()