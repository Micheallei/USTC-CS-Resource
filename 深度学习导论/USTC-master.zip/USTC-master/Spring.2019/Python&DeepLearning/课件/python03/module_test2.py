# -*- coding: utf-8 -*-

from module_example import *
if __name__ == "__main__":
    print_info() 
    
    a = TestClass(20)
    a.doSth()