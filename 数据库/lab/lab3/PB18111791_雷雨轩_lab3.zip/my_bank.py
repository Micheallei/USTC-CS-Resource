from flask import Flask,redirect,render_template, url_for,request, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date
from models import Loan, Cusforloan, Employee, Payinfo,Bank,  Checkacc, Cusforacc,Customer, Account, Saveacc
from sqlalchemy import func
from models import db
import config
import calendar

app = Flask(__name__)
app.config.from_object(config)

db.init_app(app)

with app.app_context():
    db.create_all()

@app.route('/')
def hello_world():
    return redirect(url_for('index'))

@app.route('/index')
def index():#菜单页面
    acc_num = db.session.query(func.count(Account.accountID)).scalar()
    bank_num = db.session.query(func.count(Bank.bankname)).scalar()
    loan_num = db.session.query(func.count(Loan.loanID)).scalar()
    cus_num = db.session.query(func.count(Customer.cusID)).scalar()
    return render_template('index.html', bank_num=bank_num, cus_num=cus_num, loan_num=loan_num, acc_num=acc_num)

@app.route('/loan/create' , methods=['GET', 'POST'])
def loan_create():
    labels = ["贷款号*", "身份证号*","贷款银行*","贷款金额*"]
    names = ["loanID", "cusID", "bank", "money"]
    init_form = {item: '' for item in names}
    if request.method == 'GET':
        return render_template('loan/create.html', init_form=init_form, labels=labels, names=names)
    if request.method == 'POST':
        errors = []
        loanID = request.form['loanID']
        bank = request.form['bank']
        cusID = request.form['cusID']
        money = request.form['money']
        state = 'origin'
        if len(loanID) != 4:
            errors.append('loanID')
        try:
            money = float(money)
        except:
            errors.append('money')
        if len(bank) == 0 or len(bank) > 20 or Bank.query.filter_by(bankname=bank).first() is None:
            errors.append('bank')
        if Loan.query.filter_by(loanID=loanID).first():
            errors.append('loanID')
        if not Customer.query.filter_by(cusID=cusID).first():
            errors.append('cusID')
        if not errors:
            new_loan = Loan(loanID=loanID, settime=datetime.now(), money=money, rest_money=money, bank=bank, state=state)
            db.session.add(new_loan)
            new_cusforloan = Cusforloan(loanID=loanID, cusID=cusID)
            db.session.add(new_cusforloan)
            db.session.commit()
            flash('贷款 ' + loanID + ' 创建成功!')
            return render_template('loan/create.html',  init_form=init_form, errors=errors, labels=labels, names=names)
        else:
            return render_template('loan/create.html',  init_form=request.form,errors=errors, labels=labels, names=names)

@app.route('/loan/search', methods=['GET', 'POST'])
def loan_search():
    labels = ["贷款号", "身份证号", "贷款银行","贷款时间","贷款金额", "剩余金额",  "贷款状态"]
    names = ["loanID", "cusID", "bank", "settime","money", "rest_money", "state"]
    if request.method == 'GET':
        init_form = {'loanID': '', 'cusID': '', 'state': ''}
        loans = Loan.query.all()
        for loan in loans:
            setattr(loan, 'cusID', loan.cusforloan[0].cusID)
        return render_template('loan/search.html', init_form=init_form, loans=loans, labels=labels, names=names)
    if request.method == 'POST':
        loanID = request.form['loanID']
        cusID = request.form['cusID']
        loans = Loan.query.filter_by()
        state = request.form['state']
        if 'and' in request.form:
            if loanID:
                loans = loans.filter_by(loanID=loanID)
            if cusID:
                loans = loans.filter(Loan.cusforloan.any(Cusforloan.cusID==cusID))
            if state:
                loans = loans.filter_by(state=state)
        else:
            if cusID or loanID:
                loans = loans.filter(Loan.cusforloan.any(Cusforloan.cusID == cusID) | 
                (Loan.loanID == loanID))
            if state:
                loans = loans.filter_by(state=state)
        loans = loans.all()
        for loan in loans:
            setattr(loan, 'cusID', loan.cusforloan[0].cusID)
        return render_template('loan/search.html', loans=loans, init_form=request.form, labels=labels, names=names)

@app.route('/loan/update', methods=['POST'])
def loan_update():
    cusID = request.form['cusID']
    money = request.form['money']
    loanID = request.form['loanID']
    errors = []
    if len(loanID) != 4:
        errors.append('loanID')
    try:
        money = float(money)
    except:
        errors.append('money')
    if money < 0:
        errors.append('money')
    loan = Loan.query.filter_by(loanID=loanID).first()
    if not loan:
        errors.append('loanID')
    elif loan.state == 'finished':
        errors.append('loanID')
    elif loan.rest_money < money:
        errors.append('loanID')
    if loan.rest_money - money != 0:
        state = 'going'
    else:
        state = 'finished'
    #print("state: ",state)
    #print("loan.rest_money: ",loan.rest_money)
    #print("money: ",money)
    if not errors:
        loan = Loan.query.filter_by(loanID=loanID)
        bank = Bank.query.filter_by(bankname=loan.first().bank)
        bank.update(dict(money=bank.first().money - money))#更新银行存款
        loan.update(dict(state=state, rest_money=loan.first().rest_money-money))#更新贷款状态
        new_payinfo = Payinfo(loanID=loanID, cusID=cusID, money=money, paytime=datetime.now())
        db.session.add(new_payinfo)
        db.session.commit()
        flash('贷款 ' + loanID + ' 更新成功!')
        return redirect(url_for('loan_search'))
    else:
        flash('贷款 ' + loanID + ' 更新失败!')
        return redirect(url_for('loan_search'))

@app.route('/loan/delete/<loanID>')
def loan_delete(loanID):
    loan = Loan.query.filter_by(loanID=loanID)
    if loan.first().state == 'going':
        flash('贷款 ' + loanID + ' 删除失败!')
        return redirect(url_for('loan_search'))
    Cusforloan.query.filter_by(loanID=loanID).delete()
    loan.delete()
    db.session.commit()
    flash('贷款 ' + loanID + ' 删除成功!')
    return redirect(url_for('loan_search'))

@app.route('/account/create', methods=['GET', 'POST'])
def account_create():
    labels = ["账户号*", "客户身份证号*", "开户支行*", "账户类型*", "余额*","透支额度","货币类型", "利率"]
    names = ["accountID", "cusID", "bank", "accounttype","money", "overdraft","savetype", "interestrate"]
    init_form = {item: '' for item in names}
    if request.method == 'GET':
        return render_template('account/create.html', init_form=init_form, labels=labels, names=names)
    if request.method == 'POST':
        errors = []
        accountID = request.form['accountID']
        cusID = request.form['cusID']
        bank = request.form['bank']
        accounttype = request.form['accounttype']
        money = request.form['money']
        #print("accounttype: ",accounttype)
        overdraft = request.form['overdraft']
        savetype = request.form['savetype']
        interestrate = request.form['interestrate']
        if len(accountID) != 6 or Account.query.filter_by(accountID=accountID).first():
            errors.append('accountID')
        try:
            money = float(money)
        except:
            errors.append('money')
        if len(bank) == 0 or len(bank) > 20 or not Bank.query.filter_by(bankname=bank).first():
            errors.append('bank')
        if accounttype == 'saveacc':
            try:
                interestrate = float(interestrate)
            except:
                errors.append('interestrate')
            if savetype == '':
                errors.append('savetype')
        else:
            try:
                overdraft = float(overdraft)
            except:
                errors.append('overdraft')
        if not Customer.query.filter_by(cusID=cusID).first():
            errors.append('cusID')
        if not errors:
            new_account = Account(accountID=accountID, money=money, settime=datetime.now(), accounttype=accounttype)
            db.session.add(new_account)
            #db.session.commit()
            if accounttype == 'saveacc':
                new_saveaccount = Saveacc(accountID=accountID, interestrate=interestrate, savetype=savetype)
                db.session.add(new_saveaccount)
            else:
                new_checkaccount = Checkacc(accountID=accountID, overdraft=overdraft)
                db.session.add(new_checkaccount)
            #db.session.commit()
            new_cusforaccount = Cusforacc(accountID=accountID, cusID=cusID, bank=bank, visit=datetime.now(), accounttype=accounttype)
            db.session.add(new_cusforaccount)
            bank = Bank.query.filter_by(bankname=bank)
            bank.update(dict(money=bank.first().money + money))#创建了新账户，需要把该支行的存款额度增加
            db.session.commit()
            flash('创建新账户 ' + accountID + ' 成功!')
            return render_template('account/create.html', errors=errors, init_form=init_form, labels=labels, names=names)
        else:
            return render_template('account/create.html', errors=errors, init_form=request.form, labels=labels, names=names)

@app.route('/account/search', methods=['GET', 'POST'])
def account_search():
    if request.method == 'GET':
        init_form = {'accountID': '', 'cusID': '', 'accounttype': ''}
        account = Account.query.all()
        for acc in account:
            setattr(acc, 'bank', acc.cusforacc.bank)
            setattr(acc, 'cusID', acc.cusforacc.cusID)
            if acc.accounttype == 'saveacc':
                setattr(acc, 'interestrate', acc.saveacc.interestrate)
                setattr(acc, 'savetype', acc.saveacc.savetype)
            else:
                setattr(acc, 'overdraft', acc.checkacc.overdraft)
        return render_template('account/search.html', init_form=init_form, accounts=account)
    if request.method == 'POST':
        cusID = request.form['cusID']
        accounttype = request.form['accounttype']
        accountID = request.form['accountID']
        account = Account.query.filter_by()
        if 'and' in request.form:
            if accountID:
                account = account.filter_by(accountID=accountID)
            if cusID:
                account = account.filter(Account.cusforacc.has(Cusforacc.cusID==cusID))
            if accounttype:
                account = account.filter_by(accounttype=accounttype)
        else:
            if accountID or cusID:
                account = account.filter(Account.cusforacc.has(Cusforacc.cusID == cusID) | (Account.accountID == accountID))
            if accounttype:
                account = account.filter_by(accounttype=accounttype)
        account = account.all()
        for acc in account:
            setattr(acc, 'bank', acc.cusforacc.bank)
            setattr(acc, 'cusID', acc.cusforacc.cusID)
            if acc.accounttype == 'saveacc':
                setattr(acc, 'interestrate', acc.saveacc.interestrate)
                setattr(acc, 'savetype', acc.saveacc.savetype)
            else:
                setattr(acc, 'overdraft', acc.checkacc.overdraft)
        return render_template('account/search.html', init_form=request.form, accounts=account)

@app.route('/account/update', methods=['POST'])
def account_update():
    errors = []
    money = request.form['money']
    bank = request.form['bank']
    accountID = request.form['accountID']
    cusID = request.form['cusID']
    accounttype = request.form['accounttype']
    if accounttype == 'saveacc':
        savetype = request.form['savetype']
        interestrate = request.form['interestrate']
    else:
        overdraft = request.form['overdraft']
    if len(accountID) != 6:
        errors.append('accountID')
    try:
        money = float(money)
    except:
        errors.append('money')
    if accounttype == 'saveacc':
        try:
            interestrate = float(interestrate)
        except:
            errors.append('interestrate')
    else:
        try:
            overdraft = float(overdraft)
        except:
            errors.append('overdraft')
    if not Customer.query.filter_by(cusID=cusID).first():
        errors.append('cusID')
    if not errors:
        acc = Account.query.filter_by(accountID=accountID)
        bank = Bank.query.filter_by(bankname=acc.first().cusforacc.bank)
        bank.update(dict(money=bank.first().money - acc.first().money + money))
        acc.update(dict(accountID=accountID, money=money, settime=datetime.now(), accounttype=accounttype))
        if accounttype == 'saveacc':
            Saveacc.query.filter_by(accountID=accountID).update(dict(accountID=accountID, interestrate=interestrate, savetype=savetype))
        else:
            Checkacc.query.filter_by(accountID=accountID).update(dict(accountID=accountID, overdraft=overdraft))
        Cusforacc.query.filter_by(accountID=accountID).update(dict(accountID=accountID, cusID=cusID, visit=datetime.now()))
        db.session.commit()
        flash('账户 ' + accountID + ' 更新成功!')
        return redirect(url_for('account_search'))
    else:
        flash('账户 ' + accountID + ' 更新失败!')
        return redirect(url_for('account_search'))

@app.route('/account/delete/<accountID>')
def account_delete(accountID):
    account = Account.query.filter_by(accountID=accountID)
    bank = Bank.query.filter_by(bankname=account.first().cusforacc.bank)
    bank.update(dict(money=bank.first().money - account.first().money))
    Checkacc.query.filter_by(accountID=accountID).delete()
    Saveacc.query.filter_by(accountID=accountID).delete()
    Cusforacc.query.filter_by(accountID=accountID).delete()
    account.delete()
    db.session.commit()
    flash('账户 ' + accountID + ' 删除成功!')
    return redirect(url_for('account_search'))

@app.route('/customer/create', methods=['POST','GET'])
def customer_create():
    labels = ["注册支行*", "客户姓名*", "身份证号*", "家庭地址",  "电话*","联系人姓名*", "联系人电话*",  "联系人与客户关系*", "联系人Email","账户负责人", "贷款负责人"]
    names = ["bank", "cusname", "cusID", "address","cusphone", "contact_name" ,"contact_phone",  "relation", "contact_email","accres", "loanres"]
    init_form = {item: '' for item in names}

    if request.method == 'GET':
        return render_template('customer/create.html', init_form=init_form, labels=labels, names=names)
    if request.method == 'POST': 
        errors = []
        cusID = request.form['cusID']
        bank = request.form['bank']
        cusname = request.form['cusname']
        address = request.form['address']
        cusphone = request.form['cusphone']
        contact_phone = request.form['contact_phone']
        contact_name = request.form['contact_name']
        relation = request.form['relation']
        contact_email = request.form['contact_email']
        loanres = request.form['loanres']
        accres = request.form['accres']
        #检查输入数据是否合法
        if len(cusID) != 18 or Customer.query.filter_by(cusID=cusID).first():
            errors.append('cusID')
        if len(cusphone) != 11:
            errors.append('cusphone')
        if len(contact_phone) != 11:
            errors.append('contact_phone')
        if accres == '':
            accres = None
        if loanres == '':
            loanres = None
        if not errors:
            new_customer = Customer(cusID=cusID, settime=datetime.now(), bank=bank, cusname=cusname, address=address,cusphone=cusphone, contact_name=contact_name, contact_phone=contact_phone, contact_email=contact_email, relation=relation, accres=accres,loanres=loanres)
            db.session.add(new_customer)
            db.session.commit()
            flash('成功创建用户 ' + cusID + ' !')
            return render_template('customer/create.html',  init_form=init_form, labels=labels,errors=errors, names=names)
        else:
            return render_template('customer/create.html',  init_form=request.form, labels=labels, errors=errors,names=names)

@app.route('/customer/search', methods=['GET', 'POST'])
def customer_search():
    labels = ["注册银行", "客户姓名", "身份证号", "家庭地址", "电话", "联系人姓名", "联系人电话", "联系人关系", "联系人Email", "账户负责人", "贷款负责人", "注册时间"]
    names = ["bank", "cusname", "cusID", "address","cusphone", "contact_name", "contact_phone", "relation", "contact_email", "accres", "loanres", "settime"]
    if request.method == 'GET':
        init_form = {'cusname': '', 'cusID': '', 'cusphone': ''}
        customers = Customer.query.all()
        return render_template('customer/search.html', init_form=init_form, customers=customers, labels=labels, names=names)
    if request.method == 'POST':
        cusID = request.form['cusID']
        cusname = request.form['cusname']
        cusphone = request.form['cusphone']
        customers = Customer.query.filter_by()
        if 'and' in request.form:
            if cusID:
                customers=customers.filter_by(cusID=cusID)
            if cusname:
                customers=customers.filter_by(cusname=cusname)
            if cusphone:
                customers=customers.filter_by(cusphone=cusphone)
        else:
            if cusID or cusname or cusphone:
                customers=customers.filter((Customer.cusID == cusID) | (Customer.cusname == cusname) | (Customer.cusphone == cusphone))
        return render_template('customer/search.html', customers=customers.all(), init_form=request.form, labels=labels, names=names)

@app.route('/customers/update', methods=['POST'])
def customer_update():
    errors = []
    bank = request.form['bank']
    cusID = request.form['cusID']
    cusname = request.form['cusname']
    cusphone = request.form['cusphone']
    contact_phone = request.form['contact_phone']
    address = request.form['address']
    contact_name = request.form['contact_name']
    relation = request.form['relation']
    contact_email = request.form['contact_email']
    if len(cusID) != 18:
        errors.append('cusID')
    if len(cusphone) != 11:
        errors.append('cusphone')
    if len(contact_phone) != 11:
        errors.append('contact_phone')
    if not errors:
        Customer.query.filter_by(cusID=cusID).update(dict(bank=bank,cusID=cusID, cusname=cusname,address=address,cusphone=cusphone, contact_name=contact_name, contact_phone=contact_phone, relation=relation,contact_email=contact_email))
        db.session.commit()
        flash('用户 ' + cusID + ' 的信息已成功更新!')
        return redirect(url_for('customer_search'))
    else:
        flash('用户 ' + cusID + ' 的信息更新失败!')
        return redirect(url_for('customer_search'))

@app.route('/customers/delete/<cusID>')
def customer_delete(cusID):
    customer = Customer.query.filter_by(cusID=cusID)
    try:
        customer.delete()
        db.session.commit()
        flash('用户 ' + cusID + ' 删除成功')
        return redirect(url_for('customer_search'))
    except: 
        flash('用户 ' + cusID + ' 删除失败')
        return redirect(url_for('customer_search'))

@app.route('/statistics/year')
def statistics_year():
    time = '年份'
    money_stat = []
    cus_stat = []

    end_year = db.session.query(func.max(Customer.settime)).scalar().year
    colors = ['rgba(178, 167, 212, 1)', 'rgba(151, 187, 205, 1)', 'rgba(244, 188, 175, 1)']
    banks = [bank.bankname for bank in Bank.query.all()]
    for y in range(end_year - 4, end_year + 1):
        money_stat.append({
            'period': y, 
            'acc': {bank: db.session.query(func.sum(Account.money)).filter(
                    Account.cusforacc.has(Cusforacc.bank == bank)
                ).filter(
                    Account.settime.between(date(y, 1, 1), date(y, 12, 31))
                ).scalar() for bank in banks}, 
            'loan': {bank: db.session.query(func.sum(Loan.money)).filter(
                    Loan.bank == bank
                ).filter(
                    Loan.settime.between(date(y, 1, 1), date(y, 12, 31))
                ).scalar() for bank in banks}, 
        })
        cus_stat.append({
            'period': y,
            'acc': {bank: db.session.query(func.count(Account.accountID)).filter(
                Account.cusforacc.has(Cusforacc.bank == bank)
            ).filter(
                    Account.settime.between(date(y, 1, 1), date(y, 12, 31))
                ).scalar() for bank in banks},
            'loan': {bank: db.session.query(func.count(Loan.loanID)).filter(
                Loan.bank == bank
            ).filter(
                    Loan.settime.between(date(y, 1, 1), date(y, 12, 31))
                ).scalar() for bank in banks}
        })
    for stat in money_stat:
        for bank in banks:
            if stat['acc'][bank] == None:
                stat['acc'][bank] = 0
            else:
                stat['acc'][bank] = round(stat['acc'][bank], 2)
            if stat['loan'][bank] == None:
                stat['loan'][bank] = 0
            else:
                stat['loan'][bank] = round(stat['loan'][bank], 2)
    for stat in cus_stat:
        for bank in banks:
            if stat['acc'][bank] == None:
                stat['acc'][bank] = 0
            if stat['loan'][bank] == None:
                stat['loan'][bank] = 0

    return render_template('statistics.html', banks=banks, colors=colors, money_stat=money_stat, cus_stat=cus_stat, time=time)

@app.route('/statistics/quarter')
def statistics_quarter():
    time = '季度'
    money_stat = []
    cus_stat = []

    end_date = db.session.query(func.max(Customer.settime)).scalar()
    end_year = end_date.year
    end_quarter = (end_date.month - 1) // 3 + 1
    quarters = [str(end_year + (end_quarter - i - 1) // 4) + 
        'Q' + str((end_quarter + 7 - i) % 4 + 1) for i in range(4, -1, -1)]
    colors = ['rgba(178, 167, 212, 1)', 'rgba(151, 187, 205, 1)', 'rgba(244, 188, 175, 1)']
    banks = [bank.bankname for bank in Bank.query.all()]
    
    for q in quarters:
        y = int(q[:4])
        m_start = (int(q[-1]) - 1) * 3 + 1
        m_end = (int(q[-1]) - 1) * 3 + 3
        money_stat.append({
            'period': q, 
            'acc': {bank: db.session.query(func.sum(Account.money)).filter(
                    Account.cusforacc.has(Cusforacc.bank == bank)
                ).filter(
                    Account.settime.between(date(y, m_start, 1), date(y, m_end, calendar.monthrange(y, m_end)[1]))
                ).scalar() for bank in banks}, 
            'loan': {bank: db.session.query(func.sum(Loan.money)).filter(
                    Loan.bank == bank
                ).filter(
                    Loan.settime.between(date(y, m_start, 1), date(y, m_end, calendar.monthrange(y, m_end)[1]))
                ).scalar() for bank in banks}, 
        })
        cus_stat.append({
            'period': q,
            'acc': {bank: db.session.query(func.count(Account.accountID)).filter(
                Account.cusforacc.has(Cusforacc.bank == bank)
            ).filter(
                    Account.settime.between(date(y, m_start, 1), date(y, m_end, calendar.monthrange(y, m_end)[1]))
                ).scalar() for bank in banks},
            'loan': {bank: db.session.query(func.count(Loan.loanID)).filter(
                Loan.bank == bank
            ).filter(
                    Loan.settime.between(date(y, m_start, 1), date(y, m_end, calendar.monthrange(y, m_end)[1]))
                ).scalar() for bank in banks}
        })
    for stat in money_stat:
        for bank in banks:
            if stat['acc'][bank] == None:
                stat['acc'][bank] = 0
            else:
                stat['acc'][bank] = round(stat['acc'][bank], 2)
            if stat['loan'][bank] == None:
                stat['loan'][bank] = 0
            else:
                stat['loan'][bank] = round(stat['loan'][bank], 2)
    for stat in cus_stat:
        for bank in banks:
            if stat['acc'][bank] == None:
                stat['acc'][bank] = 0
            if stat['loan'][bank] == None:
                stat['loan'][bank] = 0
    return render_template('statistics.html', banks=banks, colors=colors, money_stat=money_stat, cus_stat=cus_stat, time=time)
        
@app.route('/statistics/month')
def statistics_month():
    time = '月份'
    money_stat = []
    cus_stat = []

    end_date = db.session.query(func.max(Customer.settime)).scalar()
    end_year = end_date.year
    end_month = end_date.month
    months = [str(end_year + (end_month - i - 1) // 12) + 
        'M' + str((end_month + 11 - i) % 12 + 1) for i in range(4, -1, -1)]
    colors = ['rgba(178, 167, 212, 1)', 'rgba(151, 187, 205, 1)', 'rgba(244, 188, 175, 1)']
    banks = [bank.bankname for bank in Bank.query.all()]
    for month in months:
        y = int(month[:4])
        m = int(month.split('M')[-1])
        money_stat.append({
            'period': month, 
            'acc': {bank: db.session.query(func.sum(Account.money)).filter(
                    Account.cusforacc.has(Cusforacc.bank == bank)
                ).filter(
                    Account.settime.between(date(y, m, 1), date(y, m, calendar.monthrange(y, m)[1]))
                ).scalar() for bank in banks}, 
            'loan': {bank: db.session.query(func.sum(Loan.money)).filter(
                    Loan.bank == bank
                ).filter(
                    Loan.settime.between(date(y, m, 1), date(y, m, calendar.monthrange(y, m)[1]))
                ).scalar() for bank in banks}, 
        })
        cus_stat.append({
            'period': month,
            'acc': {bank: db.session.query(func.count(Account.accountID)).filter(
                Account.cusforacc.has(Cusforacc.bank == bank)
            ).filter(
                    Account.settime.between(date(y, m, 1), date(y, m, calendar.monthrange(y, m)[1]))
                ).scalar() for bank in banks},
            'loan': {bank: db.session.query(func.count(Loan.loanID)).filter(
                Loan.bank == bank
            ).filter(
                    Loan.settime.between(date(y, m, 1), date(y, m, calendar.monthrange(y, m)[1]))
                ).scalar() for bank in banks}
        })
    for stat in money_stat:
        for bank in banks:
            if stat['acc'][bank] == None:
                stat['acc'][bank] = 0
            else:
                stat['acc'][bank] = round(stat['acc'][bank], 2)
            if stat['loan'][bank] == None:
                stat['loan'][bank] = 0
            else:
                stat['loan'][bank] = round(stat['loan'][bank], 2)
    for stat in cus_stat:
        for bank in banks:
            if stat['acc'][bank] == None:
                stat['acc'][bank] = 0
            if stat['loan'][bank] == None:
                stat['loan'][bank] = 0
    return render_template('statistics.html', banks=banks, colors=colors, money_stat=money_stat, cus_stat=cus_stat, time=time)

@app.errorhandler(404)
def page_not_found(e):
    return render_template('error.html'),404

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)