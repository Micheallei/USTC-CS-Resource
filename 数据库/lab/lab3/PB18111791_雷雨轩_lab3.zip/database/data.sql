#插入支行信息
insert into bank value('b1', '北京', 50000000);
insert into bank value('b2', '北京', 40000000);
insert into bank value('a1', '上海', 60000000);
insert into bank value('a2', '上海', 30000000);
insert into bank value('c1', '南京', 50000000);
insert into bank value('d1', '合肥', 50000000);


#插入部门信息
insert into department value('0000', '北京一部','后勤','510322199910210038','b1');
insert into department value('0001', '北京二部','管理','510322199910210039','b2');
insert into department value('0002', '合肥一部','后勤','510322199910210040','d1');
insert into department value('0003', '南京一部','后勤','510322199910210041','c1');
insert into department value('0004', '上海一部','后勤','510322199910210042','a2');
insert into department value('0005', '北京三部','后勤','510322199910210043','b2');

#插入员工信息
insert into employee value('510322199910210038', '雷雨轩','18990035900','北京','1','2021-01-11',"0000");
insert into employee value('510322199910210039', '雷1','18990035901','北京','1','2021-01-11',"0001");
insert into employee value('510322199910210040', '雷2','18990035902','合肥','1','2021-01-11',"0002");
insert into employee value('510322199910210041', '雷3','18990035903','南京','1','2021-01-11',"0003");
insert into employee value('510322199910210042', '雷4','18990035904','上海','1','2021-01-11',"0004");
insert into employee value('510322199910210043', '雷5','18990035905','北京','1','2021-01-11',"0005");
insert into employee value('510322199910210044', '李1','18990035906','北京','0','2021-01-11',"0000");
insert into employee value('510322199910210045', '李2','18990035907','北京','0','2021-01-11',"0001");
insert into employee value('510322199910210046', '李3','18990035908','合肥','0','2021-01-11',"0002");
insert into employee value('510322199910210047', '李4','18990035909','南京','0','2021-01-11',"0003");
insert into employee value('510322199910210048', '李5','18990035910','上海','0','2021-01-11',"0004");
insert into employee value('510322199910210049', '李6','18990035911','北京','0','2021-01-11',"0005");

