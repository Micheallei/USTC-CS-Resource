use lab3;

create table bank ( #支行
	bankname	VARCHAR(20)		not null,
	city		VARCHAR(20)		not null,
	money		DOUBLE			not null,
	constraint PK_BANK primary key (bankname)
);

create table department (#部门
	departID		CHAR(4)			not null,
    departname		VARCHAR(20)		not null,
    departtype		VARCHAR(15),
    manager			CHAR(18)		not null,#部门经理身份证号
    bank			VARCHAR(20)		not null,#所属支行名字
    constraint PK_DEPARTMENT primary key (departID),
	Constraint FK_BANK_DEPART Foreign Key(bank) References bank(bankname)
);

create table employee (#银行员工
	empID			CHAR(18)		not null,
    empname			VARCHAR(20)		not null,
    empphone		CHAR(11),
    empaddr			VARCHAR(50),
    emptype			CHAR(1),#经理(1)或者普通员工(0)
    empstart		DATE			not null,#工作的开始日期
    depart			CHAR(4), #所在部门
    constraint PK_EMPLOYEE primary key (empID),
	Constraint FK_DEPART_EMP Foreign Key(depart) References department(departID),
	Constraint CK_EMPTYPE Check(emptype IN ('0','1'))
);

create table customer (#客户信息
	cusID			CHAR(18)		not null,
    settime         DATETIME, #客户创建日期
    bank            VARCHAR(20),
	cusname			VARCHAR(10)		not null,
	cusphone		CHAR(11)		not null,
	address			VARCHAR(50),
	contact_phone	CHAR(11)		not null,
	contact_name	VARCHAR(10)		not null,
	contact_email	VARCHAR(20),
	relation		VARCHAR(10)		not null,
    loanres			CHAR(18),#贷款负责人
    accres			CHAR(18),#账户负责人
	constraint PK_CUSTOMER primary key (cusID),
    Constraint FK_CUS_LOANRES Foreign Key(loanres) References employee(empID),
    Constraint FK_CUS_ACCRES Foreign Key(accres) References employee(empID)
);

create table account(
	accountID		CHAR(6)			not null,
	money			DOUBLE			not null,#余额
    settime			DATETIME,#开户日期
	accounttype		VARCHAR(10),#账户类型,saveacc或checkacc
	constraint PK_ACC primary key (accountID),
	Constraint CK_ACCOUNTTYPE Check(accounttype IN ('saveacc','checkacc'))
);

create table saveacc (
	accountID		CHAR(6)			not null,
    interestrate	float,#利率
    savetype		VARCHAR(10),#货币类型
    constraint PK_SAVEACC primary key (accountID),
	Constraint FK_SAVE_ACC Foreign Key(accountID) References account(accountID) On Delete Cascade
);

create table checkacc (
	accountID		CHAR(6)			not null, 
    overdraft		DOUBLE,#透支额
    constraint PK_CHECKACC primary key (accountID),
	Constraint FK_CHECK_ACC Foreign Key(accountID) References account(accountID) On Delete Cascade
);

create table cusforacc (
	accountID		CHAR(6)			not null,
    bank			VARCHAR(20),
    cusID			CHAR(18)		not null,
    visit			DATETIME,#最近访问日期
    accounttype		VARCHAR(10),
    constraint PK_CUSACC primary key (accountID, cusID),
    Constraint FK_BANK_ACCOUT Foreign Key(bank) References bank(bankname),
    Constraint FK_CUS Foreign Key(cusID) References customer(cusID),
	Constraint FK_CUS_ACC Foreign Key(accountID) References account(accountID) On Delete Cascade,
    Constraint UK Unique Key(bank, cusID, accounttype)#客户在一个支行里只能有一个支票账户和一个储蓄账户
);

create table loan (
	loanID			CHAR(4)			not null,
    settime         DATETIME ,
    money			DOUBLE,
    rest_money      DOUBLE,
    bank			VARCHAR(20),#由哪个支行发放
    state			VARCHAR(10)		default 'origin', #'origin', 'going', 'finished'分别表示未开始发放，发放中，已全部发放
    constraint PK_LOAN primary key (loanID),
	Constraint FK_BANK_LOAN Foreign Key(bank) References bank(bankname)
);

create table cusforloan (
	loanID			CHAR(4),
    cusID			CHAR(18),
    constraint PK_CUSLOAN primary key (loanID, cusID),
    Constraint FK_LOAN Foreign Key(loanID) References loan(loanID) On Delete Cascade,
    Constraint FK_CUSL Foreign Key(cusID) References customer(cusID)
);

create table payinfo (
	loanID			CHAR(4),
    cusID			CHAR(18),
    money			DOUBLE,
    paytime			DATETIME,
    constraint PK_PAYINFO primary key (loanID, cusID, money, paytime),
    Constraint FK_PAY_LOAN Foreign Key(loanID) References loan(loanID) On Delete Cascade,
    Constraint FK_PAY_CUS Foreign Key(cusID) References customer(cusID)
);  



